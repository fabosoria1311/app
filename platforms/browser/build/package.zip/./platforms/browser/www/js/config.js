window.config = {
	// wsUrl : 'http://107.170.54.69:8080/EtaBackApp/webresources/rest/',
	// wsUrl : 'http://ec2-35-164-188-119.us-west-2.compute.amazonaws.com/ws/',
	wsUrl : 'http://107.170.54.69:8080/eta-mobile-interface/etaws/etamobile/',
	wsTimeout : 10000,
	wsDataType : 'json',
	wsCallType : 'GET',

	ciaParameter : 'E',

	defaultWsErrorMsg : 'Hubo un error, por favor intentalo mas tarde',
	
	pushContent : '',
	
}