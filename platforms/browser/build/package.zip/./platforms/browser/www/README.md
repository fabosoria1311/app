This is a side menu ionic framework starter template.

https://github.com/driftyco/ionic-starter-sidemenu