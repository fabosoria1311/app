//alau.controller('mainController', function($scope, $route, $location, $routeParams) {
alau.controller('EtaCtrl', [ '$scope', '$location', '$routeParams', function($scope, $route, $location, $routeParams) {

} ]);